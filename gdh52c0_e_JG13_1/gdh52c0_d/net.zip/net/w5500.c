#include "w5500.h"
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"


#define WIZ_SCS			  GPIO_PIN_7	//  GPIO_Pin_12	
#define WIZ_SCLK			GPIO_PIN_3	//GPIO_Pin_13	
#define WIZ_MISO			GPIO_PIN_4	//GPIO_Pin_14	
#define WIZ_MOSI			GPIO_PIN_5	//GPIO_Pin_15	
#define WIZ_INT			  GPIO_PIN_8	//GPIO_Pin_4	// PC4

#define WIZ_RESET_PIN		GPIO_PIN_9	
#define WIZ_RESET_PORT      GPIOC 

#define DATA_BUF_SIZE    2000

 dma_parameter_struct dma_data_parameter;

static uint8 I_STATUS[MAX_SOCK_NUM];
static uint16 SSIZE[MAX_SOCK_NUM]; /**< Max Tx buffer size by each channel */
static uint16 RSIZE[MAX_SOCK_NUM]; /**< Max Rx buffer size by each channel */

uint8 SPI2_DMA_TxBuff[DATA_BUF_SIZE+3];





void w5500_dma_init(void)
{

	rcu_periph_clock_enable(RCU_DMA1);
	dma_deinit(DMA1, DMA_CH0);
	dma_deinit(DMA1, DMA_CH1);
	
	dma_channel_disable(DMA1, DMA_CH0);
	dma_channel_disable(DMA1, DMA_CH1);
}

void w5500_gpio_init(void)
{


	/******w5500���Ŷ���************
		SPI2_CK	 89(PB3)
		SPI2_MI	 90(PB4)
		SPI2_MO	 91(PB5)
		
	  W5500_SCSN   64(PC7)
	  W5500_INT    65(PC8)
	  W5500_RST    66(PC9)
	*******************************/
	rcu_periph_clock_enable(RCU_AF);
	rcu_periph_clock_enable(RCU_SPI2);
	rcu_periph_clock_enable(RCU_GPIOB);
	rcu_periph_clock_enable(RCU_GPIOC);
	
	gpio_pin_remap_config(GPIO_SWJ_SWDPENABLE_REMAP, ENABLE);
	
	gpio_init(GPIOB,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5);

	
	gpio_init(GPIOC,GPIO_MODE_OUT_PP,GPIO_OSPEED_50MHZ,GPIO_PIN_7|GPIO_PIN_9);
	
	gpio_init(GPIOC,GPIO_MODE_IPU,GPIO_OSPEED_50MHZ,GPIO_PIN_8);
}

void w5500_reset(void)
{
  		
  gpio_bit_reset(WIZ_RESET_PORT, WIZ_RESET_PIN);
  Delay_us(2);  
  gpio_bit_set(WIZ_RESET_PORT, WIZ_RESET_PIN);
  Delay_ms(160);


}

void Os_reset(void)
{
  		
  gpio_bit_reset(WIZ_RESET_PORT, WIZ_RESET_PIN);
  vTaskDelay(10/ portTICK_RATE_MS); 
  gpio_bit_set(WIZ_RESET_PORT, WIZ_RESET_PIN);
  vTaskDelay(100/ portTICK_RATE_MS); 


}




void WIZ_SPI_Init(void)
{
	
	
	 
	w5500_gpio_init();
	w5500_dma_init();
	
	 spi_parameter_struct spi_init_struct;
	 spi_i2s_deinit(SPI2);
	 spi_struct_para_init(&spi_init_struct);
	
	 /* SPI Config -------------------------------------------------------------*/  
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.device_mode          = SPI_MASTER;
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;//SPI_CK_PL_HIGH_PH_2EDGE;
    spi_init_struct.nss                  = SPI_NSS_SOFT;
    spi_init_struct.prescale             = SPI_PSC_2;
    spi_init_struct.endian               = SPI_ENDIAN_MSB;
    spi_init(SPI2, &spi_init_struct);
		
		while ( spi_i2s_flag_get(SPI2, SPI_FLAG_TBE)==RESET){;}//�ȴ����ͼĴ���Ϊ��
   	//spi_enable(SPI2);

}

void WIZ_CS(uint8_t val)
{
	if (val == LOW) 
	{
		
   		gpio_bit_reset(GPIOC, WIZ_SCS); 
		
	
	}
	else if (val == HIGH)
	{
		 
   		gpio_bit_set(GPIOC, WIZ_SCS); 
		
  
	}
}

uint8_t SPI2_SendByte(uint8_t byte)
{
	   while ( spi_i2s_flag_get(SPI2, SPI_FLAG_TBE)==RESET);//�ȴ����ͼĴ���Ϊ��
		  spi_i2s_data_transmit(SPI2, byte);
		 while ( spi_i2s_flag_get(SPI2, SPI_FLAG_RBNE)==RESET);//�ȴ��ͷ��Ĵ�����Ϊ��
		 return  (uint8)spi_i2s_data_receive(SPI2);
}








uint8 getISR(uint8 s)
{
  return I_STATUS[s];
}
void putISR(uint8 s, uint8 val)
{
   I_STATUS[s] = val;
}

uint16 getIINCHIP_RxMAX(uint8 s)
{
   return RSIZE[s];
}
uint16 getIINCHIP_TxMAX(uint8 s)
{
   return SSIZE[s];
}
void IINCHIP_CSoff(void)
{
  WIZ_CS(LOW);
}
void IINCHIP_CSon(void)
{
   WIZ_CS(HIGH);
}
u8  IINCHIP_SpiSendData(uint8 dat)
{
   return(SPI2_SendByte(dat));
}

void IINCHIP_WRITE( uint32 addrbsb,  uint8 data)
{
	uint8_t spi_data[4];
	
	#if !defined (SPI_DMA)
   //IINCHIP_ISR_DISABLE();                        // Interrupt Service Routine Disable
   IINCHIP_CSoff();                              // CS=0, SPI start
   IINCHIP_SpiSendData( (addrbsb & 0x00FF0000)>>16);// Address byte 1
   IINCHIP_SpiSendData( (addrbsb & 0x0000FF00)>> 8);// Address byte 2
   IINCHIP_SpiSendData( (addrbsb & 0x000000F8) + 4);    // Data write command and Write data length 1
   IINCHIP_SpiSendData(data);                    // Data write (write 1byte data)
   IINCHIP_CSon();                               // CS=1,  SPI end
   //IINCHIP_ISR_ENABLE();                         // Interrupt Service Routine Enable
	
	#else
	 spi_data[0] = (addrbsb & 0x00FF0000) >> 16;
	 spi_data[1] = (addrbsb & 0x0000FF00) >> 8;
	 spi_data[2] = ((addrbsb & 0x000000F8) + 4);
	 SPI_DMA_WRITE(spi_data, &data, 1);//д����
#endif
}

uint8 IINCHIP_READ(uint32 addrbsb)
{
	 uint8 data = 0;
	 uint8_t spi_data[3];
	
	#if !defined (SPI_DMA)   
   //IINCHIP_ISR_DISABLE();                        // Interrupt Service Routine Disable
   IINCHIP_CSoff();                              // CS=0, SPI start
   IINCHIP_SpiSendData( (addrbsb & 0x00FF0000)>>16);// Address byte 1
   IINCHIP_SpiSendData( (addrbsb & 0x0000FF00)>> 8);// Address byte 2
   IINCHIP_SpiSendData( (addrbsb & 0x000000F8))    ;// Data read command and Read data length 1
   data = IINCHIP_SpiSendData(0x00);             // Data read (read 1byte data)
   IINCHIP_CSon();                               // CS=1,  SPI end
   //IINCHIP_ISR_ENABLE();                         // Interrupt Service Routine Enable     
  #else
	 spi_data[0] = (addrbsb & 0x00FF0000) >> 16;
	 spi_data[1] = (addrbsb & 0x0000FF00) >> 8;
	 spi_data[2] = ((addrbsb & 0x000000F8));
	 SPI_DMA_READ(spi_data, &data, 1);//������
	#endif
	 return data; 
}

uint16 wiz_write_buf(uint32 addrbsb,uint8* buf,uint16 len)
{
//   uint16 idx = 0;
	 uint8_t spi_data[3];
#if !defined (SPI_DMA)  
	SPI_Cmd(SPI1, ENABLE);
   if(len == 0){;};// printf("Unexpected2 length 0\r\n");

   //IINCHIP_ISR_DISABLE();
   IINCHIP_CSoff();                              // CS=0, SPI start
   IINCHIP_SpiSendData( (addrbsb & 0x00FF0000)>>16);// Address byte 1
   IINCHIP_SpiSendData( (addrbsb & 0x0000FF00)>> 8);// Address byte 2
   IINCHIP_SpiSendData( (addrbsb & 0x000000F8) + 4);    // Data write command and Write data length 1
   for(idx = 0; idx < len; idx++)                // Write data in loop
   {
     IINCHIP_SpiSendData(buf[idx]);
   }
   IINCHIP_CSon();                               // CS=1, SPI end
   //IINCHIP_ISR_ENABLE();                         // Interrupt Service Routine Enable    
    
#else 
	 spi_data[0] = ((addrbsb & 0x00FF0000) >> 16);
	 spi_data[1] = ((addrbsb & 0x0000FF00) >> 8);
	 spi_data[2] = ((addrbsb & 0x000000F8) + 4);
	 SPI_DMA_WRITE(spi_data, buf, len);//д����
#endif	 
	 return len; 
}

uint16 wiz_read_buf(uint32 addrbsb, uint8* buf,uint16 len)
{
//  uint16 idx = 0;
	uint8_t spi_data[3];
#if !defined (SPI_DMA)  
	SPI_Cmd(SPI1, ENABLE);
  if(len == 0)
  {
      ;// printf("Unexpected2 length 0\r\n");
  }
  //IINCHIP_ISR_DISABLE();
  //SPI MODE I/F
  IINCHIP_CSoff();                                  // CS=0, SPI start
  IINCHIP_SpiSendData( (addrbsb & 0x00FF0000)>>16);// Address byte 1
  IINCHIP_SpiSendData( (addrbsb & 0x0000FF00)>> 8);// Address byte 2
  IINCHIP_SpiSendData( (addrbsb & 0x000000F8));    // Data write command and Write data length 1
  for(idx = 0; idx < len; idx++)                    // Write data in loop
  {
    buf[idx] = IINCHIP_SpiSendData(0x00);
  }
  IINCHIP_CSon();                                   // CS=1, SPI end
  //IINCHIP_ISR_ENABLE();                             // Interrupt Service Routine Enable
 
#else
	spi_data[0] = (addrbsb & 0x00FF0000) >> 16;
	spi_data[1] = (addrbsb & 0x0000FF00) >> 8;
	spi_data[2] = (addrbsb & 0x000000F8);
	SPI_DMA_READ(spi_data, buf, len);//������
#endif
	return len;
}


/**
@brief  This function is for resetting of the iinchip. Initializes the iinchip to work in whether DIRECT or INDIRECT mode
*/
void iinchip_init(void)
{
  setMR( MR_RST );
#ifdef __DEF_IINCHIP_DBG__
 ;// printf("MR value is %02x \r\n",IINCHIP_READ_COMMON(MR));
#endif
}

/**
@brief  This function set the transmit & receive buffer size as per the channels is used
Note for TMSR and RMSR bits are as follows\n
bit 1-0 : memory size of channel #0 \n
bit 3-2 : memory size of channel #1 \n
bit 5-4 : memory size of channel #2 \n
bit 7-6 : memory size of channel #3 \n
bit 9-8 : memory size of channel #4 \n
bit 11-10 : memory size of channel #5 \n
bit 12-12 : memory size of channel #6 \n
bit 15-14 : memory size of channel #7 \n
W5500��Tx, Rx�����Ĵ���������16K Bytes,\n
In the range of 16KBytes, the memory size could be allocated dynamically by each channel.\n
Be attentive to sum of memory size shouldn't exceed 8Kbytes\n
and to data transmission and receiption from non-allocated channel may cause some problems.\n
If the 16KBytes memory is already  assigned to centain channel, \n
other 3 channels couldn't be used, for there's no available memory.\n
If two 4KBytes memory are assigned to two each channels, \n
other 2 channels couldn't be used, for there's no available memory.\n
*/
void sysinit( uint8 * tx_size, uint8 * rx_size  )
{
  int16 i;
  int16 ssum,rsum;
#ifdef __DEF_IINCHIP_DBG__
 ;// printf("sysinit()\r\n");
#endif
  ssum = 0;
  rsum = 0;

  for (i = 0 ; i < MAX_SOCK_NUM; i++)       // Set the size, masking and base address of Tx & Rx memory by each channel
  {
          IINCHIP_WRITE( (Sn_TXMEM_SIZE(i)), tx_size[i]);		// MCU��¼ÿ��Socket���ͻ���Ĵ�С������tx_size[]��Ӧ��Ԫ��ֵ
          IINCHIP_WRITE( (Sn_RXMEM_SIZE(i)), rx_size[i]);		// MCU��¼ÿ��Socket���ջ���Ĵ�С������rx_size[]��Ӧ��Ԫ��ֵ
          
#ifdef __DEF_IINCHIP_DBG__
        // printf("tx_size[%d]: %d, Sn_TXMEM_SIZE = %d\r\n",i, tx_size[i], IINCHIP_READ(Sn_TXMEM_SIZE(i)));
        // printf("rx_size[%d]: %d, Sn_RXMEM_SIZE = %d\r\n",i, rx_size[i], IINCHIP_READ(Sn_RXMEM_SIZE(i)));
#endif
    SSIZE[i] = (int16)(0);
    RSIZE[i] = (int16)(0);


    if (ssum <= 16384)
    {
         switch( tx_size[i] )
      {
      case 1:
        SSIZE[i] = (int16)(1024);
        break;
      case 2:
        SSIZE[i] = (int16)(2048);
        break;
      case 4:
        SSIZE[i] = (int16)(4096);
        break;
      case 8:
        SSIZE[i] = (int16)(8192);
        break;
      case 16:
        SSIZE[i] = (int16)(16384);
      break;
      default :
        RSIZE[i] = (int16)(2048);
        break;
      }
    }

   if (rsum <= 16384)
    {
         switch( rx_size[i] )
      {
      case 1:
        RSIZE[i] = (int16)(1024);
        break;
      case 2:
        RSIZE[i] = (int16)(2048);
        break;
      case 4:
        RSIZE[i] = (int16)(4096);
        break;
      case 8:
        RSIZE[i] = (int16)(8192);
        break;
      case 16:
        RSIZE[i] = (int16)(16384);
        break;
      default :
        RSIZE[i] = (int16)(2048);
        break;
      }
    }
    ssum += SSIZE[i];
    rsum += RSIZE[i];

  }
}

// added

/*.
*/
void setGAR(
  uint8 * addr  /**< a pointer to a 4 -byte array responsible to set the Gateway IP address. */
  )
{
    wiz_write_buf(GAR0, addr, 4);
}
void getGWIP(uint8 * addr)
{
    wiz_read_buf(GAR0, addr, 4);
}

/**
@brief  It sets up SubnetMask address
*/
void setSUBR(uint8 * addr)
{   
    wiz_write_buf(SUBR0, addr, 4);
}
/**
@brief  This function sets up MAC address.
*/
void setSHAR(
  uint8 * addr  /**< a pointer to a 6 -byte array responsible to set the MAC address. */
  )
{
  wiz_write_buf(SHAR0, addr, 6);  
}

/**
@brief  This function sets up Source IP address.
*/
void setSIPR(
  uint8 * addr  /**< a pointer to a 4 -byte array responsible to set the Source IP address. */
  )
{
    wiz_write_buf(SIPR0, addr, 4);  
}

/**
@brief  W5500��������������Socket����ʱ��Ĵ���Sn_KPALVTR����λΪ5s
*/
void setkeepalive(SOCKET s)
{ 
  IINCHIP_WRITE(Sn_KPALVTR(s),0x02);
}

/**
@brief  This function sets up Source IP address.
*/
void getGAR(uint8 * addr)
{
    wiz_read_buf(GAR0, addr, 4);
}
void getSUBR(uint8 * addr)
{
    wiz_read_buf(SUBR0, addr, 4);
}
void getSHAR(uint8 * addr)
{
    wiz_read_buf(SHAR0, addr, 6);
}
void getSIPR(uint8 * addr)
{
    wiz_read_buf(SIPR0, addr, 4);
}

void setMR(uint8 val)
{
  IINCHIP_WRITE(MR,val);
}

/**
@brief  This function gets Interrupt register in common register.
 */
uint8 getIR( void )
{
   return IINCHIP_READ(IR);
}

/**
@brief  This function sets up Retransmission time.

If there is no response from the peer or delay in response then retransmission
will be there as per RTR (Retry Time-value Register)setting
*/
void setRTR(uint16 timeout)
{
  IINCHIP_WRITE(RTR0,(uint8)((timeout & 0xff00) >> 8));
  IINCHIP_WRITE(RTR1,(uint8)(timeout & 0x00ff));
}

/**
@brief  This function set the number of Retransmission.

If there is no response from the peer or delay in response then recorded time
as per RTR & RCR register seeting then time out will occur.
*/
void setRCR(uint8 retry)
{
  IINCHIP_WRITE(WIZ_RCR,retry);
}

/**
@brief  This function set the interrupt mask Enable/Disable appropriate Interrupt. ('1' : interrupt enable)

If any bit in IMR is set as '0' then there is not interrupt signal though the bit is
set in IR register.
*/
void clearIR(uint8 mask)
{
  IINCHIP_WRITE(IR, ~mask | getIR() ); // must be setted 0x10.
}

/**
@brief  This sets the maximum segment size of TCP in Active Mode), while in Passive Mode this is set by peer
*/
void setSn_MSS(SOCKET s, uint16 Sn_MSSR)
{
  IINCHIP_WRITE( Sn_MSSR0(s), (uint8)((Sn_MSSR & 0xff00) >> 8));
  IINCHIP_WRITE( Sn_MSSR1(s), (uint8)(Sn_MSSR & 0x00ff));
}

void setSn_TTL(SOCKET s, uint8 ttl)
{    
   IINCHIP_WRITE( Sn_TTL(s) , ttl);
}



/**
@brief  get socket interrupt status

These below functions are used to read the Interrupt & Soket Status register
*/
uint8 getSn_IR(SOCKET s)
{
   return IINCHIP_READ(Sn_IR(s));
}


/**
@brief   get socket status
*/
uint8 getSn_SR(SOCKET s)
{
   return IINCHIP_READ(Sn_SR(s)); // MCU��Sn_SR��Ӧ��ַ�������ֵ������
}


/**
@brief  get socket TX free buf size

This gives free buffer size of transmit buffer. This is the data size that user can transmit.
User shuold check this value first and control the size of transmitting data
*/
uint16 getSn_TX_FSR(SOCKET s)
{
  uint16 val=0,val1=0;
	uint8 buff[2];
  do
  {
//    val1 = IINCHIP_READ(Sn_TX_FSR0(s));
//    val1 = (val1 << 8) + IINCHIP_READ(Sn_TX_FSR1(s));
		wiz_read_buf(Sn_TX_FSR0(s),buff,2);
		val1=(buff[0]<<8)+buff[1];
      if (val1 != 0)
    {
//        val = IINCHIP_READ(Sn_TX_FSR0(s));
//        val = (val << 8) + IINCHIP_READ(Sn_TX_FSR1(s));
			wiz_read_buf(Sn_TX_FSR0(s),buff,2);
		  val=(buff[0]<<8)+buff[1];
    }
  } while (val != val1);
   return val;
}


/**
@brief   get socket RX recv buf size

This gives size of received data in receive buffer.
*/
uint16 getSn_RX_RSR(SOCKET s)		// ��ȡSn_RX_RSR���н��ջ���Ĵ�����ֵ������,Sn_RX_RSR�б�����ǽ��ջ������ѽ��պͱ�������ݴ�С
{
  uint16 val=0,val1=0;
	uint8 buff[2];
  do
  {
//    val1 = IINCHIP_READ(Sn_RX_RSR0(s));		
//    val1 = (val1 << 8) + IINCHIP_READ(Sn_RX_RSR1(s));		// MCU����Sn_RX_RSR��ֵ����val1
		wiz_read_buf(Sn_RX_RSR0(s),buff,2);
		val1=(buff[0]<<8)+buff[1];
    if(val1 != 0)																				// ���Sn_RX_RSR��ֵ��Ϊ0��˵�����ջ������յ�������
    {
//        val = IINCHIP_READ(Sn_RX_RSR0(s));				
//        val = (val << 8) + IINCHIP_READ(Sn_RX_RSR1(s));	// MCU����Sn_RX_RSR��ֵ����val
			wiz_read_buf(Sn_RX_RSR0(s),buff,2);
		  val=(buff[0]<<8)+buff[1];
    }
  } 
	while (val != val1);																	// ��ʱӦ��val=val1,����ʽΪ�٣�����do whileѭ��
  return val;																						// ����val
}
/**
@brief   This function is being called by send() and sendto() function also.

This function read the Tx write pointer register and after copy the data in buffer update the Tx write pointer
register. User should read upper byte first and lower byte later to get proper value.
*/
void send_data_processing(SOCKET s, uint8 *data, uint16 len)		// MCU�����ݷ��͸�W5500�Ĺ��̣�W5500������д��buf�����������ݵ�дָ��ĵ�ַ
{
  uint16 ptr =0;
  uint32 addrbsb =0;
	uint8 buff[2];
	
  if(len == 0)
  {
//    printf("CH: %d Unexpected1 length 0\r\n", s);
    return;
  }

// Sn_RX_WR�Ƿ���дָ��Ĵ������������淢�ͻ����н�Ҫ�������ݵ��׵�ַ 	
//	ptr = IINCHIP_READ( Sn_TX_WR0(s) );
//  ptr = ((ptr & 0x00ff) << 8) + IINCHIP_READ(Sn_TX_WR1(s));			// MCU��ȡSn_RX_WR�Ĵ�����ֵ
//  printf("Sn_TX_WR:0x%4x\r\n",ptr);
	wiz_read_buf(Sn_TX_WR0(s),buff,2);
	ptr=((buff[0] & 0x00ff) << 8 )+buff[1];
	
  addrbsb = (uint32)(ptr<<8) + (s<<5) + 0x10;										// �����ͻ����н�Ҫ�������ݵ��׵�ַת��32λ

  wiz_write_buf(addrbsb, data, len);														// W5500�Ӹ��׵�ַ��ʼд�����ݣ����ݳ���Ϊlen
  
	
  ptr += len;																										// �׵�ַ��ֵ+len��Ϊ�����µ��׵�ַ
	
	buff[0]=(uint8)((ptr & 0xff00) >> 8);
	buff[1]=(uint8)(ptr & 0x00ff);
	wiz_write_buf(Sn_TX_WR0(s),buff,2);
//  IINCHIP_WRITE( Sn_TX_WR0(s) ,(uint8)((ptr & 0xff00) >> 8));
//  IINCHIP_WRITE( Sn_TX_WR1(s),(uint8)(ptr & 0x00ff));						// ���µ��׵�ַ������Sn_RX_WR��

}

/**
@brief  This function is being called by recv() also.

This function read the Rx read pointer register
and after copy the data from receive buffer update the Rx write pointer register.
User should read upper byte first and lower byte later to get proper value.
*/
void recv_data_processing(SOCKET s, uint8 *data, uint16 len)
{
  uint16 ptr = 0;
  uint32 addrbsb = 0;
  uint8 buff[2];
  if(len == 0)
  {
//    printf("CH: %d Unexpected2 length 0\r\n", s);
    return;
  }
// Sn_RX_RD�ǽ��ն�ָ��Ĵ���
//  ptr = IINCHIP_READ( Sn_RX_RD0(s) );			
//  ptr = ((ptr & 0x00ff) << 8) + IINCHIP_READ( Sn_RX_RD1(s) );			// MCU��ȡSn_RX_RD�Ĵ�����ֵ

	wiz_read_buf(Sn_RX_RD0(s),buff,2);
	ptr=((buff[0] & 0x00ff) << 8 )+buff[1];
	
	
  addrbsb = (uint32)(ptr<<8) + (s<<5) + 0x18;					// �����ͻ����н�Ҫ�������ݵ��׵�ַת��32λ
  wiz_read_buf(addrbsb, data, len);										// W5500�Ӹ��׵�ַ��ʼ��ȡ���ݣ����ݳ���Ϊlen
  ptr += len;																					// �׵�ַ��ֵ+len��Ϊ�����µ��׵�ַ
  
	buff[0]=(uint8)((ptr & 0xff00) >> 8);
	buff[1]=(uint8)(ptr & 0x00ff);
	wiz_write_buf(Sn_RX_RD0(s),buff,2);
//  IINCHIP_WRITE( Sn_RX_RD0(s), (uint8)((ptr & 0xff00) >> 8));		
//  IINCHIP_WRITE( Sn_RX_RD1(s), (uint8)(ptr & 0x00ff));		// ���µ��׵�ַ������Sn_RX_RD��
}

void setSn_IR(uint8 s, uint8 val)
{
    IINCHIP_WRITE(Sn_IR(s), val);
}

void SPI_DMA_WRITE(uint8_t* Addref, uint8_t* pTxBuf, uint16_t tx_len)
{
	
	uint16_t i;
	memset(SPI2_DMA_TxBuff, 0, tx_len + 3);
	
	SPI2_DMA_TxBuff[0] = Addref[0];
	SPI2_DMA_TxBuff[1] = Addref[1];
	SPI2_DMA_TxBuff[2] = Addref[2];

	for(i=0; i<tx_len; i++)
	{
	  SPI2_DMA_TxBuff[3 + i] = pTxBuf[i];		
	}	
	

	  dma_data_parameter.number       = (uint16_t)(tx_len + 3);//���ݻ����С
	  dma_data_parameter.periph_addr  = (uint32_t)&SPI_DATA(SPI2);//�����ַ
    dma_data_parameter.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;//��ִ�������ַ����ģʽ
    dma_data_parameter.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;//�洢����ַ����
    dma_data_parameter.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;//�������ݿ���8λ
    dma_data_parameter.memory_width = DMA_MEMORY_WIDTH_8BIT; //�洢�����ݿ���8λ 
 
    dma_circulation_disable(DMA1, DMA_CH0);//��ִ��ѭ������
		dma_circulation_disable(DMA1, DMA_CH1);//��ִ��ѭ������
    dma_data_parameter.priority     = DMA_PRIORITY_HIGH;//���ȼ�--��
    
		dma_memory_to_memory_disable(DMA1, DMA_CH0);//�洢�����洢��ʧ��
		dma_memory_to_memory_disable(DMA1, DMA_CH1);//�洢�����洢��ʧ��
		

	
	
	
	
	  


  /* Configure TX DMA */
	
	dma_data_parameter.direction    = DMA_MEMORY_TO_PERIPHERAL;//���ݴ��䷽��洢�������裨�Ӵ洢������
	dma_data_parameter.memory_addr  = (uint32_t )SPI2_DMA_TxBuff ;//���ݴ洢��ַ
	dma_init(DMA1, DMA_CH1, &dma_data_parameter);
	
  /* Configure RX DMA */

  dma_data_parameter.direction    = DMA_PERIPHERAL_TO_MEMORY;;//���ݴ��䷽�����赽�洢�������������
	dma_data_parameter.memory_addr  = (uint32_t )SPI2_DMA_TxBuff ;//���ݴ洢��ַ
	dma_init(DMA1, DMA_CH0, &dma_data_parameter);

	
  IINCHIP_CSoff(); 
	
	/* Enable the SPI1 Tx DMA request */
     spi_dma_enable(SPI2, SPI_DMA_TRANSMIT);
		 spi_dma_enable(SPI2, SPI_DMA_RECEIVE);
    

  /* Enable the DMA SPI1 TX Stream */
	 dma_channel_enable(DMA1, DMA_CH1);
	/* Enable the DMA SPI1 RX Stream */
   dma_channel_enable(DMA1, DMA_CH0);
   spi_enable(SPI2);
	 
  /* Waiting the end of Data transfer */
    while(dma_flag_get(DMA1, DMA_CH1, DMA_FLAG_FTF)==RESET);//�ȴ����ݴ������
		while(dma_flag_get(DMA1, DMA_CH0, DMA_FLAG_FTF)==RESET);
  
	IINCHIP_CSon(); 
	

    dma_flag_clear(DMA1, DMA_CH1, DMA_FLAG_FTF);
    dma_flag_clear(DMA1, DMA_CH0, DMA_FLAG_FTF);
  

    dma_channel_disable(DMA1, DMA_CH1);
    dma_channel_disable(DMA1, DMA_CH0);
		

     spi_dma_disable(SPI2, SPI_DMA_TRANSMIT);
	   spi_dma_disable(SPI2, SPI_DMA_RECEIVE);
		 
	 spi_disable(SPI2);
}

void SPI_DMA_READ(uint8_t* Addref, uint8_t* pRxBuf, uint16_t rx_len)
{
//	uint16_t i;
	
	memset(SPI2_DMA_TxBuff, 0, rx_len + 3);//�巢�ͻ���

	SPI2_DMA_TxBuff[0] = Addref[0];  //��ȡ����ַ
	SPI2_DMA_TxBuff[1] = Addref[1];
	SPI2_DMA_TxBuff[2] = Addref[2];

#if 0
	printf("rx len: %d\r\n", rx_len);
	printf("Rx Data: ");
	for(i=0; i<rx_len; i++)
		printf("%02X ", SPI2_DMA_TxBuff[i]);
	printf("\r\n");

	printf("pTmpBuf1: ");
	for(i=0; i<rx_len + 3; i++)
		printf("%02X ", SPI2_DMA_TxBuff[i]);
	printf("\r\n");
#endif
//����DMA	
	

    dma_data_parameter.number       = (uint16_t)(rx_len + 3);//���ݻ����С
	  dma_data_parameter.periph_addr  = (uint32_t)&SPI_DATA(SPI2);//�����ַ
    dma_data_parameter.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;//��ִ�������ַ����ģʽ
    dma_data_parameter.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;//�洢����ַ����
    dma_data_parameter.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;//�������ݿ���8λ
    dma_data_parameter.memory_width = DMA_MEMORY_WIDTH_8BIT; //�洢�����ݿ���8λ 
		
		 dma_circulation_disable(DMA1, DMA_CH1);//��ִ��ѭ������
		dma_circulation_disable(DMA1, DMA_CH0);//��ִ��ѭ������
    dma_data_parameter.priority     = DMA_PRIORITY_HIGH;//���ȼ�--��
    
		dma_memory_to_memory_disable(DMA1, DMA_CH1);//�洢�����洢��ʧ��
		dma_memory_to_memory_disable(DMA1, DMA_CH0);//�洢�����洢��ʧ��



  /* Configure TX DMA */
  dma_data_parameter.direction    = DMA_MEMORY_TO_PERIPHERAL;;//���ݴ��䷽�����赽�洢�������������
	dma_data_parameter.memory_addr  = (uint32_t )SPI2_DMA_TxBuff ;//���ݴ洢��ַ
	dma_init(DMA1, DMA_CH1, &dma_data_parameter);


  /* Configure RX DMA */
  dma_data_parameter.direction    = DMA_PERIPHERAL_TO_MEMORY;;//���ݴ��䷽�����赽�洢�������������
	dma_data_parameter.memory_addr  = (uint32_t )SPI2_DMA_TxBuff ;//���ݴ洢��ַ
	dma_init(DMA1, DMA_CH0, &dma_data_parameter);

  IINCHIP_CSoff(); 
	
		/* Enable the SPI Rx DMA request */
		 spi_dma_enable(SPI2, SPI_DMA_RECEIVE);
     spi_dma_enable(SPI2, SPI_DMA_TRANSMIT);
	
	/* Enable the DMA SPI TX Stream */
	  dma_channel_enable(DMA1, DMA_CH1);
	/* Enable the DMA SPI RX Stream */
	 dma_channel_enable(DMA1, DMA_CH0);
		 spi_enable(SPI2);
	
  /* Waiting the end of Data transfer */
     while(dma_flag_get(DMA1, DMA_CH1, DMA_FLAG_FTF)==RESET);
		 while(dma_flag_get(DMA1, DMA_CH0, DMA_FLAG_FTF)==RESET);

  IINCHIP_CSon(); 
	
    dma_flag_clear(DMA1, DMA_CH1, DMA_FLAG_FTF);
    dma_flag_clear(DMA1, DMA_CH0, DMA_FLAG_FTF);

    dma_channel_disable(DMA1, DMA_CH1);
    dma_channel_disable(DMA1, DMA_CH0);
    

    
	   spi_dma_disable(SPI2, SPI_DMA_RECEIVE);
     spi_dma_disable(SPI2, SPI_DMA_TRANSMIT);

	  spi_disable(SPI2);      

	memcpy(pRxBuf, SPI2_DMA_TxBuff + 3, rx_len);
#if 0
	printf("Rx Data: ");
	for(i=0; i<rx_len; i++)
		printf("%02X ", SPI2_DMA_RxBuff[i]);
	printf("\r\n");
#endif
}

/*-------------------------------------------------------------------------*/
/*��	PHYCFGR�Ĵ�����ֵ		                                         ------*/
/*------------------------------------------------------------------------*/
uint8 getPHYCFGR(void)
{
	uint8 addr;
	wiz_read_buf(PHYCFGR, &addr, 1);
	//wiz_read_buf(VERSIONR, &addr, 1);
	return addr;
}


