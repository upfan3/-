#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "w5500.h"
#include "socket.h"
#include "http_server.h"
#include "utility.h"
//#include "webpage.h"

#include "FreeRTOS.h"
#include "task.h"
//#include "filebase.h"



//�յ����ݲ���0~9��A~F���ڣ�����0����ʾ�յ�������Ч
u8 httpAsciitoHex(u8 *op,u8* pdat)
{ u8 i=2,tmp;
	 
	  if((*pdat<0x30)||(*pdat==0x40)||(*pdat>0x46)) return 0;
	    if((*(pdat+1)<0x30)||(*(pdat+1)==0x40)||(*(pdat+1)>0x46)) return 0;
	     *op=0;
	while(i--)
	{
	    if( *pdat<0x40)
			{
				  tmp=*pdat-0x30;
				
			}
			if(*pdat>0x40)
			{
				tmp=*pdat-0x37;
			}
			   pdat++;
			
			  *op=*op|(tmp<<(i*4));
		}
	  return 1;
}
 


_RX_STR *gprxinfo=NULL;
//_RX_STR *gptxinfo=NULL;
st_http_request *gphttp_request=NULL;	/*����http������ͷ�Ľṹ��ָ��*/

/*-------------------------------------------------------------------------*/
/*	ת��ת���ַ�Ϊascii charater 						 -----*/
/*   ����url����Ҫת����ҳ��ַ                                     */
/*------------------------------------------------------------------------*/
void unescape_http_url(char * url)
{
  int x, y;
  
  for (x = 0, y = 0; url[y]; ++x, ++y) 
  {
    if ((url[x] = url[y]) == '%') 
	{
      url[x] = c2d(url[y+1])*0x10+c2d(url[y+2]);
      y+=2;
    }
  }
  url[x] = '\0';
}
/*-------------------------------------------------------------------------*/
/*   ִ��һ���𸴣��� html, gif, jpeg,etc.				  -----*/
/*   ����buf- ������ type- ���������� len-  �����ݳ���     */
/*------------------------------------------------------------------------*/
void make_http_response_head(unsigned char * buf,char type,uint32 len)
{
  char * head;
  char tmp[10];
  memset(buf,0x00,MAX_URI_SIZE); 
  /* �ļ�����*/
  if 	(type == PTYPE_HTML) head = RES_HTMLHEAD_OK;
  else if (type == PTYPE_GIF)	head = RES_GIFHEAD_OK;
  else if (type == PTYPE_TEXT)	head = RES_TEXTHEAD_OK;
  else if (type == PTYPE_JPEG)	head = RES_JPEGHEAD_OK;
  else if (type == PTYPE_FLASH)	head = RES_FLASHHEAD_OK;
  else if (type == PTYPE_MPEG)	head = RES_MPEGHEAD_OK;
  else if (type == PTYPE_PDF)	head = RES_PDFHEAD_OK;
  else if (type == PTYPE_PDF)	head = RES_PDFHEAD_OK;
	else if (type == PTYPE_JSON)	head = RES_JSONHEAD_OK;
	else if (type == PTYPE_JS)	head = RES_JAVASCRIPT_OK;
	else if (type == PTYPE_CSS)	head = RES_CSS_OK;
	else if (type == PTYPE_XML) 	head = RES_XML_OK;
	
  sprintf(tmp,"%ld", len);	
  strcpy((char*)buf, head);
  strcat((char*)buf, tmp);
  strcat((char*)buf, "\r\n\r\n");
  //printf("%s\r\n", buf);
}
 /*-------------------------------------------------------------------------*/
 /*  Ѱ��һ��MIME�����ļ� 			                               -----*/
 /*   ����buf- MIME���ļ� type-��������	                                   */
 /*------------------------------------------------------------------------*/
void find_http_uri_type(u_char * type, char * buf) 
{
  /* Decide type according to extention*/
  if 	(strstr(buf, ".pl"))				*type = PTYPE_PL;
  else if (strstr(buf, ".html") || strstr(buf,".htm"))	*type = PTYPE_HTML;
  else if (strstr(buf, ".gif"))				*type = PTYPE_GIF;
  else if (strstr(buf, ".text") || strstr(buf,".txt"))	*type = PTYPE_TEXT;
  else if (strstr(buf, ".jpeg") || strstr(buf,".jpg"))	*type = PTYPE_JPEG;
  else if (strstr(buf, ".swf")) 				*type = PTYPE_FLASH;
  else if (strstr(buf, ".mpeg") || strstr(buf,".mpg"))	*type = PTYPE_MPEG;
  else if (strstr(buf, ".pdf")) 				*type = PTYPE_PDF;
  else if (strstr(buf, ".cgi") || strstr(buf,".CGI"))	*type = PTYPE_CGI;
  else if (strstr(buf, ".js") || strstr(buf,".JS"))	*type = PTYPE_TEXT;	
  else if (strstr(buf, ".xml") || strstr(buf,".XML"))	*type = PTYPE_HTML;
  else 							*type = PTYPE_ERR;
}
 /*-------------------------------------------------------------------------*/
 /*   ����ÿһ��http��Ӧ			                               -----*/
 /*   ����request�� ����һ��ָ��                                   */
 /*------------------------------------------------------------------------*/ 
void parse_http_request(st_http_request * request,u_char * buf)
{
  char * nexttok;
	char * gflagend;
	u8 strlenth;
	//request=(st_http_request *)buf;
  nexttok = strtok((char*)buf," ");
  if(!nexttok)
  {
    request->METHOD = METHOD_ERR;
    return;
  }
  if(!strcmp(nexttok, "GET") || !strcmp(nexttok,"get"))
  {
    request->METHOD = METHOD_GET;
	  	nexttok = strtok(NULL," ");
   			
  }
  else if (!strcmp(nexttok, "HEAD") || !strcmp(nexttok,"head"))	
  {
    request->METHOD = METHOD_HEAD;
    nexttok = strtok(NULL," ");
  		
  }
  else if (!strcmp(nexttok, "POST") || !strcmp(nexttok,"post"))
  {
   
    
    request->METHOD = METHOD_POST;
 		 nexttok = strtok(NULL," ");
  }
  else
  {
    request->METHOD = METHOD_ERR;
  }	 
  if(!nexttok)
  {
    request->METHOD = METHOD_ERR; 			
    return;
  }
  //strcpy(request->FileNAME,nexttok); 	
    gflagend=strstr(nexttok,"?");
    strlenth=strlen(nexttok);
	   if(gflagend!=NULL)
	   strlenth=strlenth-strlen(gflagend);
	  //memset (request->FileNAME,0,16);
	  memcpy(request->FileNAME,nexttok,strlenth);
   request->FileNAME[strlenth]=0x00;
		  request->pdata=nexttok+strlenth+1;
	
}

////////////////////////////////////////
//�ֲ�post����//////
//1ȡ��CID1��CID2
//2�����ݲ���������7�ֽڣ�ԭʼ����Ϊ14�֣���CMD���鴫��,������NULL
//3�����ݲ�������7�ֽڣ�ԭʼ����Ϊ14�֣������ڴ�ռ䷵������ָ��
//4�����ݲ�������7�ֽڣ�ԭʼ����Ϊ14�֣�����������ЧҲ����NULL
////////////////////////////////////////
unsigned char *get_post_1363(char *p,unsigned char * cmd,unsigned char n)
{unsigned char tmp_buf[3];
	uint16 len;
	unsigned char * ptmpdata=NULL;
	for(u8 i=0 ;i<n;i++)
	{
	    char *p1=strstr(p,"=");
	    char *p2=strstr(p,"&");
	    len=p2-p1-1;
		if(i<2) //cid1,cid2Ϊʮ����������
		{
		  memset(tmp_buf,0,3);
		  memcpy(tmp_buf,p1+1,len);
		  cmd[i]=ATOI((char *)tmp_buf,10);
		}
		else// data ��ʮ�����ƴ���
		{ 
			
			  if(len<=14)
				{
					for(u8 j=0;j<len/2;j++)
					{
						 memset(tmp_buf,0,3);
						 memcpy(tmp_buf,p1+1+j*2,2);
						 httpAsciitoHex(&cmd[i+j],&tmp_buf[0]);
						
					}
				}
				else
				{
					 ptmpdata=(unsigned char *)pvPortMalloc(sizeof(unsigned char)*len/2);
					 if(ptmpdata!=NULL)
					 {
						 
						 for(u8 j=0;j<len/2;j++)
							{
								 memset(tmp_buf,0,3);
								 memcpy(tmp_buf,p1+1+j*2,2);
								if( httpAsciitoHex(&ptmpdata[j],&tmp_buf[0])==0){ 
									   vPortFree(ptmpdata);
									return NULL;//�����ͳ�����ֱ���Զ�
								}
								
							}
					 }
				}
		}
		p=p2+1;
	}
	return  ptmpdata;
}



 /*-------------------------------------------------------------------------*/
 /*   �õ���Ӧ�����е���һ������		                               -----*/
 /*   ����url����Ҫת����ҳ��ַ                                   */
 /*------------------------------------------------------------------------*/  


char get_http_param_value(char* uri,char ** ppuri)
{
	uint16 len;
	uint8* pos2;
	uint8* name=0; 
	
	uint16 content_len=0;
	int8 tmp_buf[10]={0x00,};
	if(!uri ) return 0;
	/***************/
	mid(uri,"Content-Length: ","\r\n",tmp_buf);
	content_len=ATOI(tmp_buf,10);
	uri = (int8*)strstr(uri,"\r\n\r\n");
	uri+=4;
	//printf("uri=%s\r\n",uri);
	uri[content_len]='&';//����һ��������־���Ա�����ַ���ȡ
	*ppuri=uri;
   len=strlen(uri);
	if(content_len==(len-1))//�Ƚ�ʵ���յ����ݳ�����Ԥ�����ݳ��ȣ��Ƿ�һ��
	/***************/	 
	 return 1;
	else
	 return 0;
}



///////////////////////////////////////httputil//////////////////////////////

extern CONFIG_MSG  ConfigMsg;
char tx_buf[MAX_URI_SIZE];

void make_json_data( char * pjsondata,u8 cid1,u8 cid2,u8 *pdat,u8 type)
{//char a[5]={2,3,4,5,6};
  memset(pjsondata,0x00,MAX_URI_SIZE); 

	//sprintf(pjsondata,"{\"V1\":%d, \"I1\":%d,\"I2\":%d,\"W2\":%d,\"W1\":%d}",a[0],a[1],a[2],a[3],a[4]);
	if(type==0)
   sprintf(pjsondata,"{\"cid1\":%d, \"cid2\":%d,\"data\":\"%s\"}",cid1,cid2,pdat);
	else
	  sprintf(pjsondata,"{\"cid1\":%d, \"cid2\":%d,\"err\":\"%d\"}",cid1,cid2,*pdat);	
}



//char *senttmpbuff[10]={0,0,0,0,0,0,0,0,0,0};
u8 *ptxbuff=NULL;
//u8 writebuffCount=0;//д����
//u8 readbuffCount=0;//������
//u8 entyflag=1;//�ձ�־
/*-------------------------------------------------------------------------*/
/*	 ����http						  -----*/
/*------------------------------------------------------------------------*/    
void proc_sent(SOCKET s,const char *sentbuff,uint16 lenth)
{
	
	unsigned long file_len=0;														
	uint16 send_len=0,len;
	send_len=0;
	

//	ptxbuff=(u8 *)pvPortMalloc(sizeof(u8)*1025);
//	 ptxbuff[1024]=0;
	gprxinfo->rx_buff[1024]=0;
	file_len = strlen((const char*)sentbuff);
	if(lenth>0)
		file_len=lenth;
	while(file_len)
	{
		if(file_len>1024)
		{
			if(getSn_SR(s)!=SOCK_ESTABLISHED)
			{
				//vPortFree(ptxbuff);
				return;
			}
			memcpy(gprxinfo->rx_buff,(uint8 *)sentbuff+send_len,1024);
			send(s,gprxinfo->rx_buff, 1024);
			
			send_len+=1024;
			file_len-=1024;
		}
		else
		{
			memcpy(gprxinfo->rx_buff,(uint8 *)sentbuff+send_len,file_len);						
			gprxinfo->rx_buff[file_len]=0;	
			send(s, gprxinfo->rx_buff, file_len);
			send_len+=file_len;
			file_len-=file_len;
		} 
	}



   // vPortFree(ptxbuff);


}


u8 http_proc_send(SOCKET s)
{
	
//	static  u8 isbusy=0;
//	static  uint16 send_len=0,len;
//	static  unsigned long file_len=0;
//	
//	static  char *sentbuff_=NULL;
//		
//	
//	
//	if(entyflag==1) return entyflag;
//	/*����http������ͷ�Ľṹ��ָ��*/
//	
//	ptxbuff=(u8 *)pvPortMalloc(sizeof(u8)*1025);
//	
//	
//	if(isbusy==0)
//	{
//	   send_len=0;
//	 
//		   ptxbuff[1024]=0;
//		  sentbuff_=senttmpbuff[readbuffCount++];
//	   file_len = strlen((const char*)sentbuff_);
//		 if(readbuffCount==10) readbuffCount=0;
//		 isbusy=1;
//	}
//	else if(isbusy==1)
//	{		
//		 if(file_len>1024)
//		{
//			if(getSn_SR(s)!=SOCK_ESTABLISHED)
//			{
//				 vPortFree(ptxbuff);
//				return 1;
//			}
//			memcpy(ptxbuff,(uint8 *)sentbuff_+send_len,1024);
//			send(s, ptxbuff, 1024);
//			
//			send_len+=1024;
//			file_len-=1024;
//		}
//		else
//		{
//			memcpy(ptxbuff,(uint8 *)sentbuff_+send_len,file_len);						
//			ptxbuff[file_len]=0;	
//			send(s, ptxbuff, file_len);
//			send_len+=file_len;
//			file_len-=file_len;
//			isbusy=0;
//			if(readbuffCount==writebuffCount) entyflag=1;
//			
//			
//		} 
//		
//	}
//	
//	
//	
//	 vPortFree(ptxbuff);
//	return  entyflag;
	
	
}






/*-------------------------------------------------------------------------*/
/*	 ����http�����Ĳ�����http��Ӧ							  -----*/
/*   ����s: http������socket  buf��������������                           */
/*------------------------------------------------------------------------*/    

void proc_http(SOCKET s, uint8 * buf,PTRFUN_PCH pFun)
{
	int8* context; 											
	  int8 req_name[10]={0x00,};		/*����һ��http��Ӧ���ĵ�ָ��*/
    int8 req_name1[10]={0x00,};															
	
	unsigned long file_len=0;															

	uint8* http_response;            /*����һ��http��Ӧ���ĵ�ָ��*/

	st_http_request *phttp_request=gphttp_request;
	http_response=(uint8*)tx_buf;	

	parse_http_request(phttp_request, buf);    							/*����http������ͷ*/
	  
	switch (phttp_request->METHOD)		
    {
		case METHOD_ERR :																			/*������ͷ����*/
			memcpy(http_response, ERROR_REQUEST_PAGE, sizeof(ERROR_REQUEST_PAGE));
			//send(s, (uint8 *)http_response, strlen((int8 const*)http_response));
			break;
		
		case METHOD_HEAD:			/*HEAD����ʽ*/
			
		case METHOD_GET:			/*GET����ʽ*/
		    
			//context = http_request->FileNAME;
		
			if(strcmp(phttp_request->FileNAME,"/index.htm")==0 || strcmp(phttp_request->FileNAME,"/")==0 || (strcmp(phttp_request->FileNAME,"/index.html")==0))
			{  //testconut[0]=1;
			
				file_len = strlen((const char *)PAGE_DEFAULT);		
				//file_len=PAGE_CSS-PAGE_DEFAULT;
				make_http_response_head((uint8*)http_response, PTYPE_HTML,file_len);			
				send(s,http_response,strlen((char const*)http_response));
				proc_sent(s,(const char *)PAGE_DEFAULT,0);
				
				
				
			}
			/*
			else if(strcmp(phttp_request->FileNAME,"/Logo.png")==0)
			{ //testconut[1]=1;
		
				
						file_len = 0x13ee;			
						make_http_response_head((uint8*)http_response, PTYPE_JPEG,file_len);			
						send(s,http_response,strlen((char const*)http_response));
						proc_sent(s,(const char *)PAGE_LOGO,file_len);
			}*/
			else if(strcmp(phttp_request->FileNAME,"/mnc.png")==0)
			{ //testconut[1]=1;
		
				
						file_len = MNCLOGO_LEN;			
						make_http_response_head((uint8*)http_response, PTYPE_JPEG,file_len);			
						send(s,http_response,strlen((char const*)http_response));
						proc_sent(s,(const char *)LOGO_MNC,file_len);
			}
			else if(strcmp(phttp_request->FileNAME,"/power.png")==0)
			{ //testconut[1]=1;
		
				
						file_len =PWRLOGO_LEN;			
						make_http_response_head((uint8*)http_response, PTYPE_JPEG,file_len);			
						send(s,http_response,strlen((char const*)http_response));
						proc_sent(s,(const char *)LOGO_POWER,file_len);
			}
			
			else if(strcmp(phttp_request->FileNAME,"/Default.css")==0)
			{ //testconut[2]=1;
				  file_len = strlen((const char *)PAGE_CSS);	
				//file_len=PTYPE_JS-PAGE_CSS;
				make_http_response_head((uint8*)http_response, PTYPE_CSS,file_len);			
				send(s,http_response,strlen((char const*)http_response));
				proc_sent(s,(const char *)PAGE_CSS,0);
			}
			else if(strcmp(phttp_request->FileNAME,"/YDT1363.js")==0)
			{ //testconut[3]=1;
				file_len = strlen((const char *)PAGE_1363_JS);	
          
        //  file_len=PAGE_WEB_JS-PTYPE_JS;				
				make_http_response_head((uint8*)http_response, PTYPE_JS,file_len);			
				send(s,http_response,strlen((char const*)http_response));
				proc_sent(s,(const char *)PAGE_1363_JS,0);
				

	
			}
			else if(strcmp(phttp_request->FileNAME,"/TABLE.js")==0)
			{ //testconut[4]=1;
				  file_len = strlen((const char *)PAGE_WEB_JS);	
			//	file_len=PAGE_EQM-PAGE_WEB_JS;
				make_http_response_head((uint8*)http_response, PTYPE_JS,file_len);			
				send(s,http_response,strlen((char const*)http_response));
				proc_sent(s,(const char *)PAGE_WEB_JS,0);
				

	
			}
				else if(strcmp(phttp_request->FileNAME,"/H52C0.XML")==0)
			{// testconut[5]=1;
		
				
        file_len = strlen((const char *)PAGE_EQM);			
				make_http_response_head((uint8*)http_response, PTYPE_XML,file_len);			
				send(s,http_response,strlen((char const*)http_response));
				proc_sent(s,(const char *)PAGE_EQM,0);
			}


			break;
			
		case METHOD_POST:		/*POST����*/
			
		    if(pFun==NULL)	
         return;		
		  
			if(strcmp(phttp_request->FileNAME,"/Default.htm")==0)	
			{ unsigned char cmd[10];
				u8 ttemp=get_http_param_value((char *)phttp_request->pdata,&phttp_request->pdata);
				if(ttemp==0)
				{
					return;
				}
				unsigned char *pdat=get_post_1363(phttp_request->pdata,cmd,3);
				     u8 * pdatainfo= (u8*)pFun(cmd,pdat);
				
				   
		
				    if(pdatainfo!=NULL)
						{
							 make_json_data( (char *)gprxinfo->rx_buff,cmd[0],cmd[1],pdatainfo,0);//��������
							   vPortFree(pdatainfo);	//�ͷ� pdatainfo���ڴ棬	���ڴ���pFun(cmd)��Ӧ�ĺ������롣
                   pdatainfo	= NULL;	
							
						}
						else
						{
							if(cmd[1]==0x45)
							{ u8 tmp=0;
								 make_json_data( (char *)gprxinfo->rx_buff,cmd[0],cmd[1],&tmp,1);//���� rtn==0
							}
							
							if(cmd[1]==0xD4)
							{
								 u8 tmp=7;
								 make_json_data( (char *)gprxinfo->rx_buff,cmd[0],cmd[1],&tmp,1);//���� rtn==7
							}
							
							
						}
				
				  if(pdat!=NULL)
						 {
							  vPortFree(pdat);//�ͷ���get_post_1363�������ڴ�ռ�
						 }
				
				
				
				
				  file_len=strlen((const char *)gprxinfo->rx_buff);
					make_http_response_head((uint8*)http_response, PTYPE_JSON,file_len);
				 file_len=strlen((const char *)http_response);
					sprintf((char *)http_response+file_len,"%s",gprxinfo->rx_buff);
				  send(s,http_response,strlen((char const*)http_response));
				
			}
				
		   
			break;
			
		default :
			break;
	}

 






}



