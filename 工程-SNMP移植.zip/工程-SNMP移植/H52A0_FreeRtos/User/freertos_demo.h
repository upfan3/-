/*************************************************************************
 *WKS GD32F470ZIT6���İ�
 *FreeRTOS��ֲʵ��
 *************************************************************************/

#ifndef __FREERTOS_DEMO_H
#define __FREERTOS_DEMO_H

void freertos_demo(void);

#endif
