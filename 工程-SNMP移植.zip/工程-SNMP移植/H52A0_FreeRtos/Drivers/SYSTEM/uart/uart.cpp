#include "uart.h"
#include "string.h"

template <uint32_t BUFFER_SIZE>
UART<BUFFER_SIZE>::UART(UART_Port port) : m_port(port), m_baudrate(0), m_usart(0),
                                          m_txDmaChannel(DMA_CH0), m_rxDmaChannel(DMA_CH0), m_dmaPeriph(0),
                                          m_txSub_periph(DMA_SUBPERI0), m_rxSub_periph(DMA_SUBPERI0),
                                          m_rs485Gpio(0), m_rs485TxEnPin(0),
                                          m_receiveLength(0), m_receiveComplete(false),
                                          m_transmitComplete(true), // ��ʼ״̬Ϊ�������
                                          m_receiveCallback(0), m_transmitCompleteCallback(0),
                                          m_receiveUserData(0), m_transmitUserData(0)
{
    // ����ʵ��ָ�룬�����жϴ���
    if (port < UART_MAX)
    {
        s_instances[port] = this; // ����ǰʵ��ע�ᵽ��̬����
    }
}

template <uint32_t BUFFER_SIZE>
UART<BUFFER_SIZE>::~UART()
{
    // ���ʵ��ָ��
    if (m_port < UART_MAX)
    {
        s_instances[m_port] = 0;
    }
}

template <uint32_t BUFFER_SIZE>
bool UART<BUFFER_SIZE>::init(uint32_t baudrate, DataBits databits, StopBits stopbits, Parity parity, FlowControl flowcontrol)
{
    m_baudrate = baudrate;

    // ʹ����Ӧ��UARTʱ�Ӳ�����USART����ַ��DMAͨ��
    switch (m_port)
    {
    case UART_0:
        rcu_periph_clock_enable(RCU_USART0);
        m_usart = USART0;
        m_txDmaChannel = DMA_CH7;
        m_rxDmaChannel = DMA_CH5;

        m_txSub_periph = DMA_SUBPERI4;
        m_rxSub_periph = DMA_SUBPERI4;

        m_dmaPeriph = DMA1;
        break;
    case UART_1:
        rcu_periph_clock_enable(RCU_USART1);
        m_usart = USART1;
        m_txDmaChannel = DMA_CH6;
        m_rxDmaChannel = DMA_CH5;

        m_txSub_periph = DMA_SUBPERI4;
        m_rxSub_periph = DMA_SUBPERI4;
        m_dmaPeriph = DMA0;
        break;
    case UART_2:
        rcu_periph_clock_enable(RCU_USART2);
        m_usart = USART2;
        m_txDmaChannel = DMA_CH3;
        m_rxDmaChannel = DMA_CH1;

        m_txSub_periph = DMA_SUBPERI4;
        m_rxSub_periph = DMA_SUBPERI4;
        m_dmaPeriph = DMA0;
        break;
    case UART_3:
        rcu_periph_clock_enable(RCU_UART3);
        m_usart = UART3;
        m_txDmaChannel = DMA_CH4;
        m_rxDmaChannel = DMA_CH2;

        m_txSub_periph = DMA_SUBPERI4;
        m_rxSub_periph = DMA_SUBPERI4;

        m_dmaPeriph = DMA0;
        break;
    case UART_4:
        rcu_periph_clock_enable(RCU_UART4);
        m_usart = UART4;
        m_txDmaChannel = DMA_CH7;
        m_rxDmaChannel = DMA_CH0;

        m_txSub_periph = DMA_SUBPERI4;
        m_rxSub_periph = DMA_SUBPERI4;

        m_dmaPeriph = DMA0;
        break;
    case UART_5:
        rcu_periph_clock_enable(RCU_USART5);
        m_usart = USART5;
        m_txDmaChannel = DMA_CH6;
        m_rxDmaChannel = DMA_CH2;

        m_txSub_periph = DMA_SUBPERI5;
        m_rxSub_periph = DMA_SUBPERI5;

        m_dmaPeriph = DMA1;
        break;

    default:
        return false;
    }

    // ��ʼ��GPIO
    initGPIO();

    // ����UART����
    usart_deinit(m_usart);
    usart_baudrate_set(m_usart, baudrate);

    // ��������λ
    switch (databits)
    {
    case DATA_BITS_8:
        usart_word_length_set(m_usart, USART_WL_8BIT);
        break;
    case DATA_BITS_9:
        usart_word_length_set(m_usart, USART_WL_9BIT);
        break;
    }

    // ����ֹͣλ
    switch (stopbits)
    {
    case STOP_BITS_1:
        usart_stop_bit_set(m_usart, USART_STB_1BIT);
        break;
    case STOP_BITS_0_5:
        usart_stop_bit_set(m_usart, USART_STB_0_5BIT);
        break;
    case STOP_BITS_2:
        usart_stop_bit_set(m_usart, USART_STB_2BIT);
        break;
    case STOP_BITS_1_5:
        usart_stop_bit_set(m_usart, USART_STB_1_5BIT);
        break;
    }

    // ����У��λ
    switch (parity)
    {
    case PARITY_NONE:
        usart_parity_config(m_usart, USART_PM_NONE);
        break;
    case PARITY_ODD:
        usart_parity_config(m_usart, USART_PM_ODD);
        break;
    case PARITY_EVEN:
        usart_parity_config(m_usart, USART_PM_EVEN);
        break;
    }

    // ����������
    switch (flowcontrol)
    {
    case FLOW_CONTROL_NONE:
        usart_hardware_flow_cts_config(m_usart, USART_CTS_DISABLE);
        usart_hardware_flow_rts_config(m_usart, USART_RTS_DISABLE);
        break;
    case FLOW_CONTROL_RTS:
        usart_hardware_flow_cts_config(m_usart, USART_CTS_DISABLE);
        usart_hardware_flow_rts_config(m_usart, USART_RTS_ENABLE);
        break;
    case FLOW_CONTROL_CTS:
        usart_hardware_flow_cts_config(m_usart, USART_CTS_ENABLE);
        usart_hardware_flow_rts_config(m_usart, USART_RTS_DISABLE);
        break;
    case FLOW_CONTROL_RTS_CTS:
        usart_hardware_flow_cts_config(m_usart, USART_CTS_ENABLE);
        usart_hardware_flow_rts_config(m_usart, USART_RTS_ENABLE);
        break;
    }

    // ʹ�ܷ��ͺͽ���
    usart_transmit_config(m_usart, USART_TRANSMIT_ENABLE);
    usart_receive_config(m_usart, USART_RECEIVE_ENABLE);

    // ��ʼ��DMA
    initDMA();

    // ��ʼ���ж�
    initInterrupt();

    // ʹ��UART
    usart_enable(m_usart);

    return true;
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::initGPIO()
{
    // ���ݲ�ͬ��UART�˿�������Ӧ��GPIOʱ�Ӻ�����
    switch (m_port)
    {

    case UART_0:
        rcu_periph_clock_enable(RCU_GPIOA);
        // ����PA9 (TX) �� PA10 (RX)
        gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_9 | GPIO_PIN_10);
        gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_9);
        gpio_af_set(GPIOA, GPIO_AF_7, GPIO_PIN_9 | GPIO_PIN_10);
        break;

    case UART_1:
        rcu_periph_clock_enable(RCU_GPIOD);
        // ����PD5 (TX) �� PD6 (RX)
        gpio_mode_set(GPIOD, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_5 | GPIO_PIN_6);
        gpio_output_options_set(GPIOD, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_5);
        gpio_af_set(GPIOD, GPIO_AF_7, GPIO_PIN_5 | GPIO_PIN_6);

        m_rs485Gpio = GPIOD;
        m_rs485TxEnPin = GPIO_PIN_4;
        gpio_mode_set(m_rs485Gpio, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, m_rs485TxEnPin);
        gpio_output_options_set(m_rs485Gpio, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, m_rs485TxEnPin);

        break;

    case UART_2:
        rcu_periph_clock_enable(RCU_GPIOC);
        // ����PC10 (TX) �� PC11 (RX)
        gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_10 | GPIO_PIN_11);
        gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_10);
        gpio_af_set(GPIOC, GPIO_AF_7, GPIO_PIN_10 | GPIO_PIN_11);

        m_rs485Gpio = GPIOC;
        m_rs485TxEnPin = GPIO_PIN_12;
        gpio_mode_set(m_rs485Gpio, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, m_rs485TxEnPin);
        gpio_output_options_set(m_rs485Gpio, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, m_rs485TxEnPin);
        break;

    case UART_3:
        rcu_periph_clock_enable(RCU_GPIOA);
        // ����PA0 (TX) �� PA1 (RX)
        gpio_mode_set(GPIOA, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_0 | GPIO_PIN_1);
        gpio_output_options_set(GPIOA, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_0);
        gpio_af_set(GPIOA, GPIO_AF_8, GPIO_PIN_0 | GPIO_PIN_1);
        break;

    case UART_4:
        rcu_periph_clock_enable(RCU_GPIOC);
        rcu_periph_clock_enable(RCU_GPIOD);
        // ����PC12 (TX) �� PD2 (RX)
        gpio_mode_set(GPIOC, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_12);
        gpio_mode_set(GPIOD, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_2);
        gpio_output_options_set(GPIOC, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_12);
        gpio_af_set(GPIOC, GPIO_AF_8, GPIO_PIN_12);
        gpio_af_set(GPIOD, GPIO_AF_8, GPIO_PIN_2);
        break;

    case UART_5:
        rcu_periph_clock_enable(RCU_GPIOG);
        // ����PG14 (TX) �� PG9 (RX)
        gpio_mode_set(GPIOG, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_PIN_14 | GPIO_PIN_9);
        gpio_output_options_set(GPIOG, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_14);
        gpio_af_set(GPIOG, GPIO_AF_8, GPIO_PIN_14 | GPIO_PIN_9);

        m_rs485Gpio = GPIOG;
        m_rs485TxEnPin = GPIO_PIN_13;
        gpio_mode_set(m_rs485Gpio, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, m_rs485TxEnPin);
        gpio_output_options_set(m_rs485Gpio, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, m_rs485TxEnPin);

        break;

    // ����UART�˿ڵ�GPIO���ÿ��Ը��������ֲ�����
    default:
        break;
    }
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::initDMA()
{
    // ʹ����Ӧ��DMAʱ��
    switch (m_dmaPeriph)
    {
    case DMA0:
        rcu_periph_clock_enable(RCU_DMA0);
        break;
    case DMA1:
        rcu_periph_clock_enable(RCU_DMA1);
        break;

    default:
        break;
    }

    // ���÷���DMA
    dma_deinit(m_dmaPeriph, m_txDmaChannel);

    dma_single_data_parameter_struct dma_init_struct;

    dma_single_data_para_struct_init(&dma_init_struct);

    dma_init_struct.direction = DMA_MEMORY_TO_PERIPH;        /*   DMAͨ�����ݴ��䷽��Ϊ�Ӵ洢�������� */
    dma_init_struct.memory0_addr = (uint32_t)0;              /* DMA �洢��0����ַ*/
    dma_init_struct.memory_inc = DMA_MEMORY_INCREASE_ENABLE; /* �洢����ַ����ģʽ */

    dma_init_struct.periph_addr = (uint32_t)(m_usart + 0x04); // USART_DATA�Ĵ���ƫ�Ƶ�ַ
    dma_init_struct.periph_inc = DMA_PERIPH_INCREASE_DISABLE; /* �����ַ�̶�ģʽ */

    dma_init_struct.periph_memory_width = DMA_PERIPH_WIDTH_8BIT; /* �������ݴ������:8λ */

    dma_init_struct.priority = DMA_PRIORITY_MEDIUM; /* ���ȼ��� */
    dma_init_struct.number = 0;                     /* DMAͨ�����ݴ�����������, ������dma_enable�������� */
    dma_init_struct.circular_mode = DMA_CIRCULAR_MODE_DISABLE;

    dma_single_data_mode_init(m_dmaPeriph, m_txDmaChannel, &dma_init_struct);

    dma_channel_subperipheral_select(m_dmaPeriph, m_txDmaChannel, m_txSub_periph); /* DMAͨ������ѡ�� */

    // ���ý���DMA
    dma_deinit(m_dmaPeriph, m_rxDmaChannel);
    dma_init_struct.direction = DMA_PERIPH_TO_MEMORY;         /* DMAͨ�����ݴ��䷽��Ϊ�����赽�洢�� */
    dma_init_struct.memory0_addr = (uint32_t)m_receiveBuffer; /* DMA �洢��0����ַ*/
    dma_init_struct.number = BUFFER_SIZE;
    dma_init_struct.circular_mode = DMA_CIRCULAR_MODE_DISABLE; /* �ر�ѭ��ģʽ */

    dma_single_data_mode_init(m_dmaPeriph, m_rxDmaChannel, &dma_init_struct);
    dma_channel_subperipheral_select(m_dmaPeriph, m_rxDmaChannel, m_rxSub_periph); /* DMAͨ������ѡ�� */

    // ʹ�ܽ���DMA
    dma_channel_enable(m_dmaPeriph, m_rxDmaChannel);

    // ʹ��UART��DMA���ͺͽ���

    usart_dma_receive_config(m_usart, USART_RECEIVE_DMA_ENABLE);
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::initInterrupt()
{
    // �����ж����ȼ�
    uint8_t irqNum = 0;
    switch (m_port)
    {
    case UART_0:
        irqNum = USART0_IRQn;
        break;
    case UART_1:
        irqNum = USART1_IRQn;
        break;
    case UART_2:
        irqNum = USART2_IRQn;
        break;
    case UART_3:
        irqNum = UART3_IRQn;
        break;
    case UART_4:
        irqNum = UART4_IRQn;
        break;
    case UART_5:
        irqNum = USART5_IRQn;
        break;
    default:
        return;
    }

    // �����ж����ȼ�
    nvic_irq_enable(irqNum, 2, 0);

    // ʹ�ܿ����ж�
    usart_interrupt_enable(m_usart, USART_INT_IDLE); // ʹ�ܿ����ж�
    usart_interrupt_enable(m_usart, USART_INT_TC);   // ʹ�ܷ�������ж�
}

template <uint32_t BUFFER_SIZE>
bool UART<BUFFER_SIZE>::send(const uint8_t *data, uint32_t length)
{
    if (isSendComplete() && data && length > 0 && length <= TRANSMIT_MAX_SIZE)
    {
        // ���÷���DMA
        dma_channel_disable(m_dmaPeriph, m_txDmaChannel);

        // �����־λ
        dma_flag_clear(m_dmaPeriph, m_txDmaChannel, DMA_FLAG_FTF);
        // �����µ�DMA����Դ
        // dma_channel_subperipheral_select(m_dmaPeriph, m_txDmaChannel, m_txSub_periph);  /* DMAͨ������ѡ�� */
        // ���÷�����ɱ�־
        m_transmitComplete = false;
        // ���÷������ݵ�ַ
        dma_memory_address_config(m_dmaPeriph, m_txDmaChannel, DMA_MEMORY_0, (uint32_t)data);

        // ���÷������ݳ���
        dma_transfer_number_config(m_dmaPeriph, m_txDmaChannel, length);

        // ʹ�ܷ���DMA
        rs485EnableTransmit();                                         // ��ΪRS485�ӿڣ�����Ϊ����ģʽ
        usart_dma_transmit_config(m_usart, USART_TRANSMIT_DMA_ENABLE); // ʹ�ܴ���DMA����
        dma_channel_enable(m_dmaPeriph, m_txDmaChannel);               // ʹ��DMAͨ��
        return true;
    }
    return false;
}

template <uint32_t BUFFER_SIZE>
bool UART<BUFFER_SIZE>::isSendComplete() const
{
    // ���DMA�Ƿ��Ѱ������Ƶ����ڷ��ͼĴ����С�
    // return dma_flag_get(m_dmaPeriph, m_txDmaChannel, DMA_FLAG_FTF) == SET;
    return m_transmitComplete;
}

template <uint32_t BUFFER_SIZE>
uint32_t UART<BUFFER_SIZE>::getReceivedData(uint8_t *buffer, uint32_t bufferSize)
{
    if (!buffer || bufferSize == 0)
        return 0;

    uint32_t length = 0;
    if (m_receiveComplete)
    {
        // ȷ����������������С
        length = (m_receiveLength > bufferSize) ? bufferSize : m_receiveLength;

        // ��������
        memcpy(buffer, m_receiveBuffer, length);

        // ������ձ�־�ͻ�����
        m_receiveComplete = false;
        m_receiveLength = 0;
        memset(m_receiveBuffer, 0, BUFFER_SIZE);

        // ����DMA����
        dma_channel_disable(m_dmaPeriph, m_rxDmaChannel); /* �ر�DMAͨ�� */

        if (dma_flag_get(m_dmaPeriph, m_rxDmaChannel, DMA_FLAG_FTF) == SET) // ���DMA���ձ�־
        {
            dma_flag_clear(m_dmaPeriph, m_rxDmaChannel, DMA_FLAG_FTF);
        }
        dma_transfer_number_config(m_dmaPeriph, m_rxDmaChannel, BUFFER_SIZE); // ���½��ճ���
        dma_channel_enable(m_dmaPeriph, m_rxDmaChannel);
    }

    return length;
}

template <uint32_t BUFFER_SIZE>
bool UART<BUFFER_SIZE>::getReceiveLenth(uint16_t *length)
{
    if (m_receiveComplete)
    {
        *length = m_receiveLength;
        return true;
    }
    return false;
}
template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::clearReceiveBuffer()
{
    m_receiveComplete = false;
    m_receiveLength = 0;
    memset(m_receiveBuffer, 0, BUFFER_SIZE);

    // ��������DMA����
    dma_channel_disable(m_dmaPeriph, m_rxDmaChannel);
    dma_transfer_number_config(m_dmaPeriph, m_rxDmaChannel, BUFFER_SIZE);
    dma_channel_enable(m_dmaPeriph, m_rxDmaChannel);
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::setRs485ControlPins(uint32_t gpio_periph, uint32_t tx_en_pin)
{
    m_rs485Gpio = gpio_periph;
    m_rs485TxEnPin = tx_en_pin;

    // ����RS485��������Ϊ���
    if (m_rs485Gpio && m_rs485TxEnPin)
    {
        // ʹ��GPIOʱ��
        if (m_rs485Gpio == GPIOA)
            rcu_periph_clock_enable(RCU_GPIOA);
        else if (m_rs485Gpio == GPIOB)
            rcu_periph_clock_enable(RCU_GPIOB);
        else if (m_rs485Gpio == GPIOC)
            rcu_periph_clock_enable(RCU_GPIOC);
        else if (m_rs485Gpio == GPIOD)
            rcu_periph_clock_enable(RCU_GPIOD);
        else if (m_rs485Gpio == GPIOE)
            rcu_periph_clock_enable(RCU_GPIOE);
        else if (m_rs485Gpio == GPIOF)
            rcu_periph_clock_enable(RCU_GPIOF);
        else if (m_rs485Gpio == GPIOG)
            rcu_periph_clock_enable(RCU_GPIOG);

        gpio_mode_set(m_rs485Gpio, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, m_rs485TxEnPin);
        gpio_output_options_set(m_rs485Gpio, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, m_rs485TxEnPin);

        // Ĭ������Ϊ����ģʽ
        rs485EnableReceive();
    }
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::rs485EnableTransmit()
{
    if (m_rs485Gpio && m_rs485TxEnPin)
    {
        gpio_bit_set(m_rs485Gpio, m_rs485TxEnPin);
    }
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::rs485EnableReceive()
{
    if (m_rs485Gpio && m_rs485TxEnPin)
    {
        gpio_bit_reset(m_rs485Gpio, m_rs485TxEnPin);
    }
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::setReceiveCallback(ReceiveCallback callback, void *userData)
{
    m_receiveCallback = callback;
    m_receiveUserData = userData;
}

template <uint32_t BUFFER_SIZE>
void UART<BUFFER_SIZE>::handleInterrupt()
{

    // ��鷢������жϱ�־
    if (usart_interrupt_flag_get(m_usart, USART_INT_FLAG_TC) != RESET)
    {
        // �����������жϱ�־
        usart_interrupt_flag_clear(m_usart, USART_INT_FLAG_TC);

        // ���÷�����ɱ�־
        m_transmitComplete = true;

        // �ر�DMA���ڷ���
        usart_dma_transmit_config(m_usart, USART_TRANSMIT_DMA_DISABLE);

        // ���ʹ��RS485���Զ��л�������ģʽ
        rs485EnableReceive();

        // ���÷�����ɻص�����
        if (m_transmitCompleteCallback)
        {
            m_transmitCompleteCallback(m_transmitUserData);
        }
    }
    // �������жϱ�־
    if (usart_interrupt_flag_get(m_usart, USART_INT_FLAG_IDLE) != RESET)
    {
        // ��������жϱ�־
        usart_data_receive(m_usart); // ��ȡ���ݼĴ��������־
        usart_interrupt_flag_clear(m_usart, USART_INT_FLAG_IDLE);

        // ������յ������ݳ���
        m_receiveLength = BUFFER_SIZE - dma_transfer_number_get(m_dmaPeriph, m_rxDmaChannel);

        // ����DMA����
        //        dma_channel_disable(m_dmaPeriph, m_rxDmaChannel);  /* �ر�DMAͨ�� */
        //
        //
        //
        //			 if(dma_flag_get(m_dmaPeriph, m_rxDmaChannel, DMA_FLAG_FTF) == SET)//���DMA���ձ�־
        //								 {
        //											dma_flag_clear(m_dmaPeriph, m_rxDmaChannel, DMA_FLAG_FTF);
        //								 }
        //         dma_transfer_number_config(m_dmaPeriph, m_rxDmaChannel, BUFFER_SIZE);		//���½��ճ���
        //         dma_channel_enable(m_dmaPeriph, m_rxDmaChannel);

        // ���ý�����ɱ�־
        m_receiveComplete = true;

        // ��������˻ص������������
        if (m_receiveCallback)
        {
            m_receiveCallback(m_receiveUserData);
        }
    }
}
