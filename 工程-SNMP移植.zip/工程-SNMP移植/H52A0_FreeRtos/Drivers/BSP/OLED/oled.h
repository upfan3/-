#ifndef OLED_H
#define OLED_H

#include "gd32f4xx.h"
// D/C
#define OLED_RS_PORT GPIOE
#define OLED_RS_PIN GPIO_PIN_4
#define Set_OLED_RS                              \
    {                                            \
        gpio_bit_set(OLED_RS_PORT, OLED_RS_PIN); \
    }
#define Clr_OLED_RS                                \
    {                                              \
        gpio_bit_reset(OLED_RS_PORT, OLED_RS_PIN); \
    }
// RES
#define OLED_RST_PORT GPIOE
#define OLED_RST_PIN GPIO_PIN_3
#define Set_OLED_RST                               \
    {                                              \
        gpio_bit_set(OLED_RST_PORT, OLED_RST_PIN); \
    }
#define Clr_OLED_RST                                 \
    {                                                \
        gpio_bit_reset(OLED_RST_PORT, OLED_RST_PIN); \
    }

#define FONT_DATA_BASE 0x08040000
// uint16_t FONT_LEN=*(uint16_t *)FONT_DATA_BASE;//��ȡ���ֳ���

// uint32_t ASC2_1206=FONT_DATA_BASE+8;//ASCII��ģ��ʼλ�� �̶�Ϊƫ��ַ��8���ֽ�
// uint32_t FONT_1206=FONT_DATA_BASE+8+95*9;//����ģ��ʼλ�� //�ܹ�95��ascii�룬ÿ��ռ9���ֽ� �ټ���8�ֽ���Ϣ��
// uint32_t FONT_TXT=FONT_DATA_BASE+(*((uint16_t *)FONT_DATA_BASE+3));//��ʼλ�õ�4���ֽڣ�ָ���˺��������ƫ�Ƶ�ַ

class OLED
{

private:
    uint8_t GRAM[128][8];

public:
    OLED(void);
    ~OLED();
    void init();
    uint8_t write_cmd(uint8_t cmd);
    uint8_t write_data(uint8_t dat);
    void refresh_gram(void);
    void clear(void);
    void show_char(uint8_t x, uint8_t y, uint8_t chr, uint8_t size, uint8_t mode);
    void draw_point(uint8_t x, uint8_t y, uint8_t t);
};

#endif
